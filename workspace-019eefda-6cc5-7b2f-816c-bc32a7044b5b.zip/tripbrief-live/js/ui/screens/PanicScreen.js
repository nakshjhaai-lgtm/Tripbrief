import { state } from '../../state.js';
import { escapeHtml } from '../../utils/text.js';
export function PanicScreen() { const pack = state.pack; const next = pack?.critical?.nextEvent; return `<section class="panic-screen screen-enter"><p class="eyebrow">${state.online ? 'Autopilot available' : 'You’re offline'}</p><h1>PANIC MODE</h1><p style="font-size:1.25rem;font-weight:900">${pack ? 'Lifeboat Pack Ready.' : 'No Lifeboat Pack generated yet.'}</p><div class="panic-grid">
  <article class="panic-card"><span>Next</span><strong>${escapeHtml(next?.title || 'No next action confirmed')}</strong><p>${escapeHtml(next?.start || '')}</p><p>${escapeHtml(next?.locationLabel || pack?.critical?.stayAddress || 'Stay address not confirmed')}</p></article>
  <article class="panic-card"><span>Codes</span><strong class="secret" id="codesSecret">${escapeHtml(pack?.critical?.confirmationCodes?.map(c=>`${c.title}: ${c.code}`).join(' · ') || 'No codes saved')}</strong><button class="button danger" id="revealCodes">Hold to reveal</button></article>
  <article class="panic-card"><span>Show to taxi / helper</span><strong>${escapeHtml(pack?.critical?.stayAddress || 'My hotel address is not confirmed in this pack.')}</strong><p>${escapeHtml(pack?.cached?.phraseCards?.[0] || 'Please help me reach my hotel.')}</p></article>
  <article class="panic-card"><span>Offline cached</span><p>${escapeHtml(pack?.cached?.weatherSummary || 'Weather not cached yet')}</p><p>${escapeHtml(pack?.cached?.currencyCheatSheet || 'Currency not cached yet')}</p></article>
</div></section>`; }
